//KULLANICIDAN VERİ ALMA İŞLEMİ
/*
Prompt ifadesi ile birlikte javascriptde kullanıcıdan veri alınabilir.

*/


// let veri_alma1=Number(prompt("LÜTFEN 1.SAYIYI GİRİNİZ."))


// let veri_alma2=Number(prompt("Lütfen 2. Sayıyı giriniz."))

// prompt("Toplam sonucu:"+(veri_alma+veri_alma2))

/*
Kullanıcıdan aldığınız 2 adet not bilgisinin ortalamasını hesaplattırınız.
*/

// let veri_alma1=Number(prompt("LÜTFEN 1.Notu giriniz."))


// let veri_alma2=Number(prompt("Lütfen 2.Notu giriniz"))

// prompt("Notlarınız ortalaması:"+(veri_alma1+veri_alma2)/2)
//============================================================
/*
ATAMA OPERATÖRÜ

' = '     sağda bulunan veriyi soldaki değişken içerisine gönderir.  

let yas=20

İŞLEMLİ ATAMA OPERATÖRLERİ

+= , -= , *= , /= , %=


*/
//===========================================================
//Değişken değerini revize etme.
// let sayi=40
// console.log(sayi)
// sayi=100
// console.log(sayi)
// sayi= sayi + 10
// console.log(sayi)
//============================================================
//İŞLEMLİ ATAM OPERATÖRLERİ ÖRNEKLER
//let sayi=40
// sayi+=10   //sayi = sayi + 10   
//console.log(sayi)
//sayi-=20
//console.log(sayi)
//sayi*= 10  //sayi = sayi * 10
//console.log(sayi)

//=============================================================
/*
KARŞILAŞTIRMA OPERATÖRLERİ

> , < , ==(Veriler stringde olsa numberda olsa taşıdıkları veriler görünürde aynı mı buna bakar.Veri tipi önemsizdir.) , >=(Büyük veya eşit) , <=(Küçük veya eşit) , 
===(Veri tipini ve içinde taşıdığı verilerin hepsi aynı mı bunu kontrol eder.) , 
!= 

*/
// let sayi1="300" 
// let sayi2=300 

// console.log("sayi 1 sayi 2 den büyüktür:"+sayi1>sayi2)
// console.log("sayi 1 sayi 2 den küçüktür"+sayi1<sayi2)
// console.log("Sayi1 sayi2 den küçük veya eşittir.",sayi1<=sayi2)
// console.log("Sayi1 sayi2 den büyük veya eşittir.",sayi1>=sayi2)
// console.log("Sayi1 sayi2 'ye eşittir.",sayi1==sayi2)
// console.log("Sayi1 sayi2 'ye hem veri tipi olarak hemde taşıdığı değer olarak eşittir.",sayi1===sayi2)

// console.log("Sayi1 ve sayi2 nin görünürde taşıdığı veriler birbirine eşit değildir.",sayi1!=sayi2)

// console.log("Sayi1 sayi2 'ye hem veri tipi olarak hemde taşıdığı değer olarak eşit değildir.",sayi1!==sayi2)

// ! işareti herhangi bir bool ifadenin başına getirildiğinde onu tersine çevirir.(Değilini almak denir.)
// let cevap=!true
// console.log(cevap)


//NOT:True ve False arkaplanda 1 ve 0 olarak tutulduğu için herhangi bir matematiksel işleme tabi tutulabilirler.
// console.log(true+4)
// console.log(false*10)

/**
 *MANTIKSAL OPERATÖRLER

AND BAĞLACI
Bütün şartların doğru olmasının beklendiği durumlarda and bağlacı kullanılır.
And bağlacında önermeler arasında çarpma işlemi vardır.
İki önermeninde doğru olması gerekir sonucun doğru olması için.
True:1  False:0
KullanıcıAdi  &&   Şifre        Giriş_Durumu
     1               1               1
     1               0               0
     0               1               0
     0               0               0


OR BAĞLACI  
Bütün şartlar arasından sadece bir şartın doğru olmasının yeterli olduğu durumlarda or bağlacı kullanılır.
Or bağlacında önermeler arasında toplama işlemi vardır.

(KullanıcıAdi || E posta )   &&   Şifre        Giriş_Durumu
     1              0               0              0        
     1              0               1              1
     0              1               0              0
     0              1               1              1
     0              0               0              0
     0              0               1              0
    
 */


