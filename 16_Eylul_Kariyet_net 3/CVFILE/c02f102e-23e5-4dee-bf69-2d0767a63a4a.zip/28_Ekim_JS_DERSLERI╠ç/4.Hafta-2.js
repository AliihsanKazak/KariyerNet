/*
JAVASCRIPT OBJECT YAPISI

Object veri tipi anahtar-değer çiftlerini içeren karmaşık veri yapılarını temsil eder.

*/

// let kullanici={
//     ad:"Tarık",
//     soyad:"Hamarat",
//     yas:80,
//     adres:{
//          sokak:"GÜltepe",
//          mahalle:"Ümraniye",
//          ulke:"Amerika"

//     },
//     hobiler:["Fİlm izlemek","Oyun oynamak"]
// }

// let kullanicilar=[]

// kullanicilar.push(kullanici)
// console.log(kullanici)
// //console.log(kullanici.ad,kullanici.soyad,kullanici.yas)

// kullanicilar.forEach(element => {
//     console.log(element.ad,element.yas,element.adres.ulke)
// });

// console.log(kullanici["yas"])

// console.log(kullanici["adres"].sokak)

// console.log(kullanici["hobiler"][0])
// console.log(kullanici.hobiler[0])

//OBJECT YAPISINA AİT METOTLAR

// let anahtarlar=Object.keys(kullanici)
// console.log(anahtarlar)

// let degerler=Object.values(kullanici)
// console.log(degerler)


// let anahtar_deger=Object.entries(kullanici)
// console.log(anahtar_deger)


//Belirli bir anahtarın nesne içinde olup olmadığını kontrol etme
// if(kullanici.hasOwnProperty("yas")){
//     console.log("YAŞ ÖZELLĞİ VARDIR.")
// }
// else{
//     console.log("YAŞ ÖZELLĞİ YOKTUR.")
// }



//NESNE ÖZELLİKLERİNİ GÜNCELLEME
let kullanici={
    ad:"Tarık",
    soyad:"Hamarat",
    yas:80,
    adres:{
         sokak:"GÜltepe",
         mahalle:"Ümraniye",
         ulke:"Amerika"

    },
    hobiler:["Fİlm izlemek","Oyun oynamak"]
}

// kullanici.ad="ERDEM"
// kullanici["soyad"]="Kılıçlar"
// console.log(kullanici)
// //Yeni özellik ekleme

// kullanici.telefon="553-769-63-62"
// console.log(kullanici)

//-----NESNE ÖZELLİĞİ SİLMEK İÇİN------
//delete ile birlikte sadece property silinir.
// delete kullanici.ad

// console.log(kullanici)

//------------------OBJECT ASSİGN-------------------
/*aynı isme sahip key varsa hedef objede bulunan key değeri kaynaktaki ile değiştirilir.Eğer key isimleri birbirinden farklı ise bunlar obje içerisinde ayrı özellikler olarak tutulurlar.
let birlesmis_obje=Object.assign({},hedef_obje,kaynak_obje)*/


// let object1={adimiz:"TARIK",soyad:"HAMARAT"}
// let object2={ad:"ERDEM",soyad:"KILIÇLAR"}
// let birlesmis_obje=Object.assign({},object1,object2)
// console.log(birlesmis_obje)

//OBJECT CREATE =>belirtilen nesneyi kullanarak yeni bir nesne oluşturur.
let deneme_obje={renk:"Kırmızı",fiyat:"200TL"}
let yeni_nesne=Object.create(deneme_obje)

console.log(yeni_nesne.renk)
