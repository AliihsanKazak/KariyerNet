/*
DİZİLER(Array)

içinde birden fazla veriyi tutabilen özelleştirilmiş yapılara dizi denir.

*/

//İçi boş bir dizi tanımlamış oldum.
// let dizi=[]

//İçi dolu bir dizi tanımlamış oldum.

//1.yöntem
// let dolu_dizi=['Erdem','Özgür','Mehmet','Tarık']
//2. yöntem
// let sayilar=new Array(1,2,3,4,5,6)


// let dizi=['TARIK','ERDEM','ÖZGÜR','MEHMET']

// console.log(dizi[4])

// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

//let dizi=['TARIK','ERDEM','ÖZGÜR','MEHMET']

//console.log(dizi[0])
//console.log(dizi[dizi.length-1]) //Dizinin son indeksindeki elemana ulaşılır.


//Dizi elemanlarının değerini değiştirme
// console.log(dizi[0])
// dizi[0]="FATMA"
// console.log(dizi[0])

//Dizi Metotları

//Dizi içerisine Eleman Ekleme
//Push metodu dizinin sonuna eleman ekler.
// let dizi=['TARIK','ERDEM','ÖZGÜR','MEHMET']

// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

// dizi.push('Süleyman')

// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

//Pop metodu diziden eleman çıkarmaya yarar
//Dizinin sonundan eleman siler.

// dizi.pop()
// console.log("---------------------------------------------")
// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

//Dizinin başından eleman çıkarır.
// dizi.shift()

// console.log("---------------------------------------------")
// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

//Unshift() dizinin başına bir eleman ekler
// dizi.unshift("FATİH")

// console.log("---------------------------------------------")
// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }

//splice() dizinin belirli bölgesinde değişiklikler yapar.
// dizi.splice(0,2,'BURAK','DENEME')

// console.log("---------------------------------------------")
// for(i=0;i<dizi.length;i++){
//     console.log(dizi[i])
// }


//FOREACH DÖNGÜSÜ İLE ELEMANLARI YAZDIRMA
//1.Yöntem
// let dizi=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// dizi.forEach(element => {
//     console.log(element)
// });

// //2.yöntem
// dizi.forEach(function (dizi){
//     console.log(dizi)
// })

//Concat Metodu
//İKi diziyi birleştirmeye yarar.İkinci dizi ilk dizinin sonundan itibaren eklenmeye başlar.
// let isimler=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// let soyisimler=['T','E','Ö','M']
// let birlesmis_dizi=isimler.concat(soyisimler)

// birlesmis_dizi.forEach(element => {
//         console.log(element)
//     });

//Slice Metodu
//Belirli bir aralıktaki elemanları yeni bir dizi olarak döndürür.
//Son indeks dahil değil.
// let isimler=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// let ayiklanmis_elemanlar=isimler.slice(1,2)

// console.log(ayiklanmis_elemanlar)


//IndexOf belirli bir elemanın dizedeki indeksini bulur.

// let isimler=['TARIK','ERDEM','ÖZGÜR','MEHMET']

// let indeks=isimler.indexOf('TARIK')

// console.log(indeks)


//join()
// let ogrenciler=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// //Dizi elemanlarını birleştirerek bir string oluşturur.
// let ogrenciString=ogrenciler.join('-')

// console.log(typeof ogrenciString)
// console.log(ogrenciString)


//Reverse()
//Dizi elemanlarını ters çevirir.
// let isimler=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// console.log(isimler.reverse())
// console.log(isimler[0])

//Sort()
//Diziyi sıralar.Rakamsal ifadeleri küçükten büyüğe.Alfabetik ifadeleride A dan z ye sıralar

// let isimler=['TARIK','ERDEM','ÖZGÜR','MEHMET']
// console.log(isimler.sort())


//ÖRNEK:AŞAĞIDA VERİLEN SAYI LİSTESİNİ BÜYÜKTEN KÜÇÜĞE SIRALAYINIZ

// let sayilar=[11,67,99,34,23]

// console.log(sayilar.sort().reverse())


//Kullanıcıdan 3 adet isim bilgisi alınız ve bunu liste içerisine ekleyiniz.

// let isimler=[]

// for(i=0;i<3;i++)
// {
    
//     isimler.push(prompt('İsim giriniz'))
// }

// console.log(isimler)
