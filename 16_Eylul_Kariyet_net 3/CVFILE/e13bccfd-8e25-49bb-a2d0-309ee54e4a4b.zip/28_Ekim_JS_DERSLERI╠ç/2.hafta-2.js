/*
Prompt ifadesi kullanıcının klavyeden bir veri girmesini sağlar.

*/

// let kullaniciadi="t"
// let sifre="1"

// let ka=prompt("Kardeş merhaba veri gir artık.") 
// let sfr=prompt("Şifrenizi giriniz") 

// let dogruluk_kontrol= ka===kullaniciadi && sifre===sfr 
// prompt(dogruluk_kontrol)


/*
IF-ELSE IF-ELSE(Karar yapıları)

Karar yapıları sayesinde karşılaştırma operatörleri kullanılarak programın duruma uygun şekilde yanıt vermesi sağlanır.

if(koşul) 
{
   Eğer parantez içerisindeki koşulun kontrolu sonucunda true ifadesi gelirse bu parantez çalışır. 
}
else{
    eğer if ve diğer alternatif şartlar kontrol edildiğinde hiç biri true cevabını döndürmediyse en son else çalışır.

    Else önünde herhangi bir koşul belirtilmez.
}

NOT!!! --IF ELSE IF ELSE-- KARA YAPISINDA If ve else birkere kullanılır.Ama else if(alternatif şartları belirten karar yapıları) sonsuz kere kullanılabilir.

*/

// let yas=prompt("YAŞ GİRİNİZ")

// if(yas>=18) 
// {
//     console.log("Ehliyet alabilirsiniz.")
// }
// else
// {
//     console.log("Ehliyet alamazsınız")
// }

//ELSE IF 
//NOT ORTALAMASI HESAPLAYAN BİR UYGULAMA İSTEDİ
// let not1=Number(prompt("Not 1 giriniz:")) //
// let not2=Number(prompt("Not 2 giriniz:")) //

// let ortalama=(not1+not2)/2  //101 varsayım
// console.log("Ortalamanız",ortalama)
// if(ortalama>=0 && ortalama<=49) 
// {
//     console.log("Öğrenci sınıfta kaldı")
// }
// else if(ortalama>49 && ortalama<=79)
// {
//     console.log("Öğrenci Geçti")
// }
// else if(ortalama>79 && ortalama<=100)
// {
//     console.log("Öğrenci takdirle geçti")
// }
// else{
//     console.log("LÜTFEN TUTARLI BİR BİLGİ GİRİNİZ.")
// }
/*
Kullanıcıdan yaş bilgisi alın 
18-30 yaş arası => emekliliğe daha çok var
31-64 yaş arası=> emekliliğe az kalmış
65 eşit veya büyükse =>Emeklilik yaşınız gelmiştir.
*/

// ===     ==   "30"  30
// let yas=Number(prompt("Yaş:"))

// if(yas>=18 && yas<=30)
// {
//     console.log("emekliliğe daha çok var")
// }
// else if(yas>30 && yas<=64)
// {
//     console.log("Emekliliğe az kaldı")
// }
// else if(yas>64)
// {
//     console.log("EMEKLİLİK YAŞINIZ GELMİŞTİR.TEBRİKLER")
// }



