/* (ÇOKLU YORUM SATIRI)
Yorum Satırı  bu işaretlerin arasında olduğunuz sürece istediğiniz kadar yorum yazabilirsiniz.Yazılan bu yazılar Vs Code tarafından çalıştırılacak bir kod olarak algılanmaz.


Yorum bırakmamızın sebebi Bu projeyi geliştirmeye devam edecek olan geliştiriciler için bilgilendirme mesajları bırakmak ayriyetten kendimiz için hatırlatma notları bırakmak adına kullanılır.


*/
//========================================================
// çift slash ile TEKLİ YORUM SATIRI bırakılır.
//========================================================

/*
IDE(GELİŞTİRME ORTAMI)
Yazılan kodların bilgisayar diline çevirilmesi için kullanılan aracı programa IDE(Integrated Enviroment Development) denir.

Bizim kullanmakta olduğumuz ve kullanacağımız IDE =>VISUAL STUDIO CODE(VS CODE)

*/

//========================================================
/*
Ide üzerinde Yazının ekrandan taşmasını engellemek için;

Sol altta bulunan dişli işareti üzerinden => Settings =>Word wrap => On yapmanız yeterli.

*/

/*
DEĞİŞKENLER VE VERİ TİPLERİ                                 

Değişken Nedir ? 
Herhangi bir yazılım dili içerisinde ortaya çıkan veriyi üzerinde tutan ve ihtiyaç halinde çağrılıp kullanılan birimlerdir.

Değişken Tanımlama Kuralı Nasıldır ?

değişkenin_veri_tipi degisken_ad = Veri

Kurallar ?

NOT!!! Kesinlikle ve kesinlikle ingilizce karakterler içermeli.

Yanlış =>  let yaş = 27  Doğru=> let yas=27

Yanlışlar:
    ad soyad   
    -ad-soyad,ad.soyad(Kısaca özel karakterler değişken ismi tanımlarken kullanılmaz. "_" hariç)

    1ad , 2ad  ,a2d 

Doğrular:
    ad_soyad(Kebab case) 

    AdSoyad(Pascal Case) 

    adSoyad(Camel Case)

    ADSOYAD(UPPER CASE)

    _ad_soyad(Snake Case)

    adsoyad(Lower Case)


*/

//TOPLU BİR ŞEKİLDE YORUM SATIRI YAPMAK İÇİN ctrl+k+c tuşlarına basarsanız mouse ile taramış olduğunuz satırlar yorum satırı haline gelir.Yorum satırlarını kaldırmak için ise ctrl+k+u (Not:Elinizi ctrl den kaldırmadan k'ye ve c'ye basın)


// let _adSoyad="TARIK HAMARAT"
// let ad1="Tarık"

//==========================================================
/*WEB SAYFASI ÜZERİNDEN ANLIK OLARAK CONSOLE ÇIKTISINI GÖRÜNTÜLEYEBİLMEK İÇİN LİVE SERVER ' eklentisini kurmalısınız.

Sol menude bulunan extensions sekmesine tıklayınız.

Arama çubuğuna Live Server yazın ve wifi işaretine benzeyen mor renkli uygulamayı yükleyin.

Yükleme işleminden sonra ise Settings'e gelerek AutoSave özelliğini afterDelay olarak ayarlayın.
(Bu yapılan değişikliklerin anlık olarak uygulamaya yansıtılmasını sağlar.)

*/


/*
VERİ TİPLERİ NELERDİR ?

1-Metinsel Veri Tipi
    string veri tipidir.
    string tipine sahip olana değişkenlerin içinde tuttuğu veriler " " tırnak işareti içerisine yazılır.
*/

// let isim = "ERDEM"
// console.log(isim)
// //Typeof ile birlikte biz herhangi bir değişkenin veri tipini öğrenebiliriz.
// console.log(typeof isim)

/*
SAYISAL VERİ TİPİ

Sayısal veri tipinin karşılığı javascript'de number dır.


let kilo=12.5 ondalıklı sayıları göstermek için ondalık kısmıyla tam sayı kısmı arasına nokta koyulur.
*/


// let kilo=72.6
// console.log(typeof kilo)


//MANTIKSAL VERİ TİPİ
/*
BOOLEAN VERİ TİPİ 

Bu veri tipine sahip değişkenler içerisinde sadece True Yada False verisini tutar.

*/

// let dogruluk=false
// console.log(typeof dogruluk)

//UNDEFİNED(TANIMLANMAYAN DEĞİŞKENLERİN SAHİP OLDUĞU VERİ TİPİ)

// console.log(typeof dogumtarihi)

//NULL(TANIMLANAN ANCAK İÇİNDE VERİ OLMAYAN DEĞİŞKENLERİN VERİ TİPİ.)

// let null_veri=null
// console.log(typeof null_veri)


/*
OPERATÖRLER 


1-ARTİMETİK OPERATÖRLER
(Toplama işlemi dışında bütün işlemlerde iki string ifade number'a çevirilir.)

+ 
a)number ifadelerin toplanması için kullanılır
b)String ifadeleri birleştirmek için kullanılır.

*/
//Numberlarda + işareti
// let sayi1=30 //Number
// let sayi2=60 //Number
// console.log(sayi1+sayi2)

//Stringlerde + işareti
// let isim1="TARIK"
// let isim2="ERDEM"
// console.log(isim1+isim2)

//STRİNG VE INT'LERDE + İŞARETİ
// let isim1="TARIK"
// let yas=60
// console.log(isim1+yas)


// let sayi1=40
// let sayi2=60
// let sayi3=5

// console.log(sayi1-sayi2)
// console.log(sayi1*sayi2)
// console.log(sayi1/sayi2)
// console.log(5**3) //Üs almak için kullanılan bir ifade.
// console.log(sayi2%sayi3)

/*

+ toplama , - çıkarma , * çarpma , 
**  işaretin solunda bulunan sayıyı işaretin sağında bulunan sayı kadar üssünü alır. 

/ bölme işlemi

% Bölme işlemindeki kalan kısmı bize verir.
*/



