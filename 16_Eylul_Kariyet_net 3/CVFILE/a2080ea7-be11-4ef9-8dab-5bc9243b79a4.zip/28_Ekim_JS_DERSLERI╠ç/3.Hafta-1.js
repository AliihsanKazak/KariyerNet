//Switch Case

/*
Switch Case yapısı if else çok benzer

Belirli sayıdaki durumlarda if-else gibi kullanılmak üzere tercih edilir.Değişmeyecek durum sayılarında tercih edilir.
Örneğin haftanın günleri.

switch(durum)
{
    case veri1:
        case'in önündeki veri durum ile eşleşirse eşleşen case çalışır.
        break;
    case veri2:
        ...
    case veri3:
        ...
    default:
        Hiçbir case ile eşleşme durumu olmaz ise default altındaki kodlar çalışacak.
}



*/

// let haftanin_gunu = prompt("Hangi günde olduğunuzu yazınız.")
// switch (haftanin_gunu) {
//     case "pazartesi":
//         alert("Haftanın 1.günü")
//         break;
//     case "salı":
//         alert("Haftanın 2.günü")
//         break;
//     case "çarşamba":
//         alert("haftanın 3.günü")
//         break;
//     case "perşembe":
//         alert("haftanın 4.günü")
//         break;
//     case "cuma":
//         alert("haftanın 5.günü")
//         break;
//     case "cumartesi":
//         alert("haftanın 6.günü")
//         break;
//     case "pazar":
//         alert("haftanın 7.günü")
//         break;
//     default:
//         alert("Lütfen gün isimlerini doğru giriniz.")
// }

//Sizde rakamsal olarak kaçıncı günde olduğunuzu girin.Bu sayıya göre haftanın hangi gününe denk geldiğini bulun.

// let haftanin_gunu = prompt("Kaçıncı günde olduğunuzu yazınız.")
// switch (haftanin_gunu) {
//     case "1":
//         alert("Pazartesi günü")
//         break;
//     case "2":
//         alert("Salı günü")
//         break;
//     case "3":
//         alert("çarşamba günü")
//         break;
//     case "4":
//         alert("Perşembe günü")
//         break;
//     case "5":
//         alert("Cuma günü")
//         break;
//     case "6":
//         alert("Cumartesi günü")
//         break;
//     case "7":
//         alert("Pazar günü")
//         break;
//     default:
//         alert("Lütfen 1-7 arasında sayı giriniz.")
// }


//===============================================================

/*
FOR DÖNGÜSÜ

Aynı kod bloğunun birden fazla kez çalıştırılması gerektiğinde yada herhangi bir koleksiyon yapısının elemanlarına ulaşmak istendiğinde döngülerden yardım alınır.

for(var i=0;i<10 ;i++ )
{
    Başlangıç_Değeri;Çalışma_Sınırı;İ'nin artış/azalış miktarı
}


For çalışma mantığıı;

1-)İlk başta i değiişkeni için bir değer atanır.

2-)İ'nin başlangıç değeri çalışma limiti olarak belirtilen şartta True yada False mu döndürüyor bakılır.

3-)eğer bu koşul kontrol sonucu false ise döngü bloğu içerisine girmez,kodlar çalıştırılmaz.

4-)eğer true ise for parantezi içerisindeki kodlar çalıştırılır.Bütün kodlar çalışıtırılıp bitirildiğinde döngüde yukarı çıkılır ve i'nin değeri artış/azalış miktarına göre değişir.Bu değişim sonucunda hala belirtilen şartta true/false mu döndürüyor bakılır.Cevaba göre işlemler tekrarlanır.



*/




// for(var i=0;i<10;i++)
// {
//     console.log(i)
//     /*
//     1.adım => i=0;True;  i=0
//     2.adım => i=1;True;  i=1  
//     3.adım => i=2;True;  i=2
//     4.adım => i=3;True;  i=3
//     5.adım => i=4;True;  i=4 
//     ...
//     ...
//     9.adım => i=8;True;                      
//     10.adım =>i=9;True; 
//     11.adım =>i=10;False;
//     */
// }

// for(var i=0;i<3;i++)
// {
//     /*
//     i nin her bir adımda aldığı değeri ve karşılaştırmanın sonucunu yukarıdaki gibi yazınız.
//     */
//     console.log(i)
//     /**
//      * 1.adım => i=0;True  
//      * 2.adım => i=1;True
//      * 3.adım => i=2;True
//      * 4.adım => i=3;False
//      */

// }

//0-40 arasındaki çift sayıları ekrana yazdıralım.

// for(var i=0;i<40;i++) //0,1,2,3......39
// {
//     if(i%2==0)
//     {
//         console.log("Sayı çift:",i)
//     }
//     else{
//         console.log("Sayi Tek:",i)
//     }
// }


//Bir kod birden fazla kez çalıştıralacaksa aşağıdaki gibi döngülerden faydalanabilirsiniz.
for(i=0;i<3;i++)
{
    let sayi=prompt(`${i+1}.Sayiyi giriniz`)
    alert(sayi)
}












