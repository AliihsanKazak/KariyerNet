//FONKSYİONLAR(Functions)
/*
Fonksiyonlar sayesinden tekrar eden kod bloklarını en aza indiririz ve böylece clean code mantığını ön plana çıkartmış oluruz.


//Fonksiyon Tanımlama
function Fonksiyonun_Adi (){

}


function Mesaj(){

}

Fonksiyon Çeşitleri;

1-Geri Değer Döndürmeyen Fonksiyonlar
    a)Parametreli
    function Mesaj(Parametreler_Buraya){

    }
    b)Parametresiz
2-Geri Değer Döndüren Fonksiyonlar
 Not:Geri değer döndüren metotların içinde mutlaka return ifadesi bulunur.
    a)Parametreli
    b)Parametresiz


    NOT:Fonksiyonlar Çağrılmadan Çalışmazlar.

    Fonksiyon Nasıl Çağrılır ?

    fonksiyon_adi(varsa_parametreler)




*/
//======================================================================
//GERİ DEĞER DÖNDÜRMEYEN PARAMETRESİZ BİR METOT
// function Mesaj(){
// for(i=0;i<10;i++){
//     console.log('MERHABA DÜNYA')
// }
// }
//======================================================================
//GERİ DEĞER DÖNDÜRMEYEN PARAMETRELİ METOTLAR
//======================================================================
// function Mesaj(yazi){
    
//         console.log(yazi)
//         console.log(yazi)
//     }
    
// Mesaj('TARIK ASKER OLDU')

// function SayiYazdir(sayi){
//     console.log(sayi)
// }

// SayiYazdir(100)
//======================================================================
//======================================================================
//FONKSİYONLARDA BİRDEN FAZLA PARAMETRE KULLANIMI
//======================================================================
//Metot çağrıldığında verilen parametreler metodun tanımlandığı yerdeki parametrelere soldan sağa olacak şekilde sırayla yerleştirilir.Gönderilmeyen Parametre değerleri 'undefined' olarak gösterilir.
// function SayiYazdir(sayi1,sayi2,sayi3){
//     console.log(sayi1,sayi2,sayi3)
// }

// SayiYazdir(100,200,300)
//======================================================================
//======================================================================
//FONKSİYONLARDA BİRDEN FAZLA PARAMETRE KULLANIMI
//======================================================================
// function DefaultParametre(sayi1,sayi3,sayi2='DEFAULT DEĞERİ ALIR'){
//     console.log(sayi1,sayi3,sayi2)
// }

// DefaultParametre(89,200)

// function DefaultParametre(sayi1,sayi2='DEFAULT DEĞERİ ALIR',sayi3){
//     console.log(sayi1,sayi2,sayi3)
// }

// DefaultParametre(89,undefined,200)
// DefaultParametre(89,null,200)
//======================================================================
//======================================================================

//ÖRNEK:Kullanıcının girmiş olduğu iki sayıyı toplayan ve bunu ekrana çıktı olarak veren metodu yazınız.

// function SayiTopla(sayi1,sayi2){
//     console.log(sayi1+sayi2)
// }


// s1=Number(prompt('1.Sayiyi giriniz'))
// s2=Number(prompt('2.Sayiyi giriniz'))

// SayiTopla(s1,s2)


/*
//FONKSYİONLARIN ÇALIŞMA ŞEKLİ;

Fonksiyonlar Çağrıldığı yerden Tanımlandığı yere giderler.Fonksiyon parantezleri içerisindeki bütün işlemleri tamamlarlar.İşlemler bittikten sonra Tanımlandığı yerden çağrıldığı yere dönerler.

*/

//Kullanıcının belirlemiş olduğu adet kadar döngüyü çalıştıran bir fonksiyon yazınız.(Döngüde sayı yada herahngi bir mesaj yazdırılabilir.)
// function DonguCalistir(adet){
//     for(i=0;i<adet;i++){
//         console.log('TARIK')
//     }
// }

// number=Number(prompt('Sayi giriniz'))

// DonguCalistir(number)


//Kullanıcıdan alınan 2 sayı ve bir işlem bilgisine göre sayılara o işlemi uygulayan bir metot.

// function DortIslem(s1,s2,islem){
//     if(islem=='+'){
//        console.log(s1+s2)
//     }
//     else if(islem=='-'){
//        console.log(s1-s2)
//     }
// }


// DortIslem(30,100,'-')

//==============================================================================
//===========GERİ DEĞER DÖNDÜREN METOTLAR=======================================
/*

Metot çalışma mantığında çağrıldığı yerden tanımlandığı yere gittiğnde return ifadesi sayesinde tekrar geri dönerken returnun önündeki değeride gittiği yere taşır.
*/

//Geri değer döndürmeyen
// function GeriDegerDondurmeyen(){
//     toplam=100+200
//     console.log(toplam)
// }
// //Geri değer döndüren
// function GeriDegerDondur(){
//     return 100+200
// }

// // console.log(GeriDegerDondurmeyen())
// console.log(GeriDegerDondur())


//Sayı Tahmin oyunu.Kendinizin belirlemiş olduğu bir sayıyı kullanıcıdan tahmin etmesini isteyin.Eğer doğru bilirse cevap olarak True Yanlış Tahmin yaparsa cevap olarak false döndürsün.Metotdan gelen bu cevap if ile kontrol ettirilsin.True yada false'a göre bildiniz yada bilemediniz diye bir cevap dönsün.

//SAYI TAHMİN OYUNU
// const tahmin_sayisi=30

// function TahminEt(tahmin){
   
//     if(tahmin==tahmin_sayisi){
        
//         return true
//     }
//     else{
        
//         return false
//     }
// }

// sayi=Number(prompt('TAHMİN GİRİNİZ!!!'))

// kontrol=TahminEt(sayi) //True


// if(kontrol){
//     console.log('DOĞRU TAHMİN')
// }
// else{
//     if(sayi>tahmin_sayisi){
//         console.log('Sayi doğru tahmin edilmedi Tahmini küçültün')
        
//     }
//     else if(sayi<tahmin_sayisi){
        
//         console.log('Sayi doğru tahmin edilmedi Tahmini büyültün')
//     }
//     console.log('YANLIŞ TAHMİN')
// }


//Kullanıcı tarafından KENDİSİNE GÖNDERİLEN SAYININ KARESİNİ Geri döndüren BİR METOT YAZINIZ.

//1.YÖNTEM
// function KareAlma(sayi){
//   kare_sonuc = sayi*sayi
//   return kare_sonuc   
// }

// s1=prompt('Lütfen karesi alınacak sayıyı giriniz.')


// console.log(KareAlma(s1))

//2.YÖNTEM(MATH.pow Metodu ile birlikte)
//Math.pow ile herhangi bir sayının istenen kuvveti alınabilir.
// function KareAlma(sayi){
//     kare_sonuc = Math.pow(sayi,3)
//     return kare_sonuc   
//   }
  
//   s1=prompt('Lütfen karesi alınacak sayıyı giriniz.')
  
  
//   console.log(KareAlma(s1))
  

//Kullanıcıdan alınan yaş bilgisine göre ehliyet alabilir yada alamaz cevabını tekrar kullanıcıya döndüren bir metot yazınız.

// function EhliyetDurumu(yas){
//     if(yas>=18){
//         return "Ehliyet Alabilirsiniz."
//     }
//     else{
//         return "Ehliyet Alamazsınız."
//     }
// }

// yas_degiskeni=prompt('Yaşınızı giriniz.')

// console.log(EhliyetDurumu(yas_degiskeni))

//=============================================================
//====ARROW FUNCTİON=============

//1.TİP
// var toplam=(a,b) => a+b

// console.log(toplam(20,30))
//2.TİP DİKKATT!!!
// const  toplam=(a,b)=>{
//     return (
//         console.log(a+b)
//     )
// }
// toplam(30,40)


//=============================================================
//==========SCOPE KAVRAMI======================================
//Fonksyion parantezleri içinde tanımlanan değişkenlere dışarıdan erişilemez.
// function ScopeKavrami(){
//     var x=10
//     console.log(x)
// }

// ScopeKavrami()

// console.log(x) // x is not defined uyarısı alırsınız.

//Const veri tipi sabit yapıdır.Değişken değeri üzerinde herhangi bir değişiklik yapılamaz.
//const yıl_gunsayisi=365
//yıl_gunsayisi+=1 //TypeError: Assignment to constant variable hatası alırsınız

//LET VE VAR ARASINDAKİ FARK
// let x=10
// console.log(x)
// if(10>5){
    
//     let x=30
//     console.log(x)
// }

// console.log(x)

// console.log("===================================")
// var y=10
// console.log(y)
// if(10>5){
    
//     var y=30
//     console.log(y)
// }

// console.log(y)

//===================================================
//=====================CALLBACK======================

// function islem(abc){
//     console.log("İşlem Başladı")
//     abc()
//     console.log("İşlem tamamlandı")

// }

// function Mesaj(){
//     console.log("MERHABA BU MESAJ BENİM")
// }

// islem(Mesaj)



