/*
While Döngüsü

while(koşul)
{
    koşul true döndürdüğü süre boyunca while döngüsü içerisindeki kodlar çalışır.

    Ne zaman koşul false cevabını verir, o zaman döngüden çıkılır.
}

*/

//Karşılaştırma operatörleri < > <= >= vs işaretler...

// let sayi=10

// while(sayi<20) //False
// {
//   console.log(sayi)
//   sayi+=1
// }
// console.log("MERHABA")

//While döngüsü kullanarak 20 ile 50 arasındaki sayıları yazdırın. 20 ve 50 dahil olsun

// let sayi2=20
// while(sayi2<=50)
// {
//     console.log(sayi2)
//     sayi2+=1

// }

//While döngüsü kullanarak 20-50 arasındaki çift sayıları yazdırın.

//NOT: if(i%2==0) => çift sayıların bulunması
// let sayi=20

// while(sayi<=50)
// {
//     if(sayi%2==0)
//     {
//         console.log(sayi)
//     }
//     sayi++ //sayi+=1

// }

//Başlangıç ve bitiş noktalarını kullanıcıdan aldığınız bir while döngüsü tasarlayınız.
// let baslangic=Number(prompt("Başlangıç değerini giriniz."))
// let bitis=Number(prompt("Bitiş Değerini giriniz"))
      
// while(baslangic<bitis) //10<30 11<30 12<30 ... 30<30
// {
//     console.log(baslangic)
//     baslangic+=1
// }


//Break-Continue
//Break

// let sayi=20
// while(sayi<50)
// {
//     console.log(sayi)
//     if(sayi==30)
//     {
//         break
//     }
//     sayi+=1
    

// }

//Continue 

// let sayi=20
// while(sayi<50)
// {
    
//     if(sayi==30)
//     {
//         sayi+=1
//         continue //
//     }
//     console.log(sayi)
//     sayi+=1
    
    

// }


//10-20 arasında çalışan bir while döngüsünde 15'e gelince döngüden çıkmasını sağlayan kodu yazınız.
// let sayi=10

// while(sayi<20)
// {
//     if(sayi==15)
//     {
//         break
//     }
//     console.log(sayi)
//     sayi+=1


// }

//FOR-WHILE KARIŞIK ÖRNEKLER

/*
Kullanıcıdan alınan 3 adet fiyat bilgisinin ortalamasını ekrana çıktı veren programı yazınız.
*/
// for(i=0;i<3;i++)
// {
//     let sayi=prompt(`${i+1}.Sayiyi giriniz`)
//     alert(sayi)
// }


// let toplamfiyat=0
// for(i=0;i<3;i++)
// {
//     let fiyat=Number(prompt(`${i+1}.Fiyat bilgisini giriniz`))
//     toplamfiyat+=fiyat
// }
// console.log(`${toplamfiyat/3}=>Ortalama fiyat`)


//Başlangıç , bitiş ve artış miktarını kullanıcının belirlediği bir for döngüsü yazınız.

// let baslangic=Number(prompt("Lütfen başlangıç değerini giriniz"))
// let bitis=Number(prompt("Lütfen bitis değerini giriniz"))
// let artis=Number(prompt("Lütfen artis miktarini giriniz"))

// for(i=baslangic;i<bitis;i+=artis)
// {
//     console.log(i)
// }


//DÖNGÜ İLE STRING IFADELERİN KARAKTERLERİNE TEK TEK ULAŞMAK

//length=> kaç karakter vardır bunun sayısını verir.
//
let isim="TarikHA"

// console.log(isim[0])
// console.log(isim[1])
// console.log(isim[2])
// console.log(isim[3])
// console.log(isim[4])


//STATIK
// for(i=0;i<5;i++) //0 , 1 , 2 , 3  , 4 
// {
//     console.log(isim[i])
// }

//DİNAMİK VERSİYON
// for(i=0;i<isim.length;i++) //0 , 1 , 2 , 3  , 4 
// {
//     console.log(isim[i])
// }














